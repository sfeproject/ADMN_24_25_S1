package com.poste;



public class Recherche extends AppCompatActivity {
    private EditText edGouv;
    private Button btnRechercher;
    private ListView lstBureau;
    private ArrayAdapter<Bureau> adpBureau;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recherche);
        init();
    }

    private void init() {
        edGouv=findViewById(R.id.edGouvR);
        btnRechercher=findViewById(R.id.btnRechercher);
        lstBureau=findViewById(R.id.lstBureau);
        adpBureau=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1);
        lstBureau.setAdapter(adpBureau);
        ajouterEcouteurs();
        
    }

    private void ajouterEcouteurs() {
        
    }



}
