package com.poste;

public class Bureau {
    private int id;
    private String nom;
    private String codePostal;
    private String gouv;

   
    
}
