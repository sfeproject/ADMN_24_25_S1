package com.poste;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

public class Ajout extends AppCompatActivity {
    private EditText edNom;
    private EditText edCodePostal;
    private EditText edGouv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout);
        init();
    }

    private void init() {
        edNom=findViewById(R.id.edNom);
        edCodePostal=findViewById(R.id.edCodePostal);
        edGouv=findViewById(R.id.edGouv);

    }
}
